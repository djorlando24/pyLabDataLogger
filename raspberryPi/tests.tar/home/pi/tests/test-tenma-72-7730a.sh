#!/bin/bash
sigrok-cli -d tenma-72-7730:conn=1a86.e008 -O analog --samples 10
