#!/usr/bin/env python
import RPi.GPIO as GPIO
import time

pins = [24,25,26,27,20]

GPIO.setmode(GPIO.BCM)
for pin1 in pins:
	GPIO.setup(pin1, GPIO.OUT)

print("Here we go! Press CTRL+C to exit")
try:
    while 1:
      for j in range(len(pins)+1):
	for i in range(len(pins)):
          GPIO.output(pins[i], j==i)
        time.sleep(.25)
except KeyboardInterrupt:
    GPIO.cleanup()
