#!/bin/bash
sudo sigrok-cli -d uni-t-ut32x:conn=1a86.e008 -O analog --samples 10
