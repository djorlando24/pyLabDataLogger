#!/usr/bin/env python
import usb.core
import usb.util

devs=usb.core.find(find_all=True,idVendor=0x1a86,idProduct=0xe008)

for dev in devs:

    if dev.is_kernel_driver_active(0):
        reattach = True
        dev.detach_kernel_driver(0)

    print 'Device Found: %x, %x, %x' % ( dev.idVendor, dev.idProduct, dev.bcdDevice )
exit()
