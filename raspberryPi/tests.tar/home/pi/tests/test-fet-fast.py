#!/usr/bin/env python
import RPi.GPIO as GPIO
import time

# sol 1 = pin 25
# sol 2 = pin 24
pin=25
period=10.0
pulselen=500e-3
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin, GPIO.OUT)

print("Pulse %g s every %g s" % (pulselen,period))

print("Press CTRL+C to exit")
try:
    while 1:
        GPIO.output(pin, 1)
        time.sleep(pulselen)
        GPIO.output(pin, 0)
        time.sleep(period-pulselen)
except KeyboardInterrupt:
    GPIO.cleanup()
