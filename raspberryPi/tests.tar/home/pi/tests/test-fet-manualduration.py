#!/usr/bin/env python
import RPi.GPIO as GPIO
import time, sys

# sol 1 = pin 25
# sol 2 = pin 24
pin=25
waitperiod=0.1 # minimium, for safety
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin, GPIO.OUT)
GPIO.output(pin, 0)

print("Press CTRL+C to exit")
try:
    while 1:
        pulselen=0.
        while pulselen<=0:
            try:
                s=raw_input("Enter pulse length in milliseconds: ")
                pulselen = float(s)/1e3
            except ValueError:
                pulselen=0.
        GPIO.output(pin, 1)
        time.sleep(pulselen)
        GPIO.output(pin, 0)
        time.sleep(waitperiod)
except KeyboardInterrupt:
    GPIO.cleanup()
    print("\nDone\n")
