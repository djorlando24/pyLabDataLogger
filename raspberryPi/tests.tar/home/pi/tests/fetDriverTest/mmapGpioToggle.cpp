#include "mmapGpio.h"
#include "stdio.h"

const int pd=1000000;
const int pl=500000;
const int pin=24;

int main(void){
	mmapGpio rpiGpio; // instantiate an instance of the mmapGpio class
	rpiGpio.setPinDir(pin,mmapGpio::OUTPUT); // set GPIO to output
	while(1) {// toggle pin for predefined time
		   rpiGpio.writePinHigh(pin);
		   usleep(pl);
		   rpiGpio.writePinLow(pin);
                   usleep(pd-pl);
	}
        return 0;
}
