while [ 1 ]; do sudo i2cdetect -y 1; sleep 1; done
