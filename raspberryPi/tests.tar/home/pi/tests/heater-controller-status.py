#!/usr/bin/env python
# External module imports
import RPi.GPIO as GPIO
import time
import sys
import serial

# Serial port config
rs485 = serial.Serial('/dev/ttyUSB0',9600)
arduino = serial.Serial('/dev/ttyACM0',9600)

# Pin Definitons:
ledPins = [22,23,21]
inputPins = [19,20] 
inputPinDesc = ['Float switch relay','Process controller out1']

# Pin Setup:
GPIO.setmode(GPIO.BCM) # Broadcom pin-numbering scheme
for ledPin in ledPins:
        GPIO.setup(ledPin, GPIO.OUT) # LED pin set as output
        GPIO.output(ledPin, GPIO.LOW)
for butPin in inputPins:
        GPIO.setup(butPin, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # Pull down

# Main loop
print("Here we go! Press CTRL+C to exit")
try:
  while 1:
    # Handle GPIOs - turn on LED according to status.
    for i in range(len(inputPins)):
        if GPIO.input(inputPins[i]):
            GPIO.output(ledPins[i], GPIO.HIGH)
        else:
            GPIO.output(ledPins[i], GPIO.LOW)
            time.sleep(0.05)
        sys.stdout.write('%s=%i ' % (inputPinDesc[i],GPIO.input(inputPins[i])))

    # Handle Arduino ADC
    s=''
    while len(s)<1024:
        s+=arduino.read(1)
	if s[-1] == '\n':
            s=s.strip()
            break
    # Convert signal to actual voltage...
    try: v=float(s.split('=')[-1].strip())
    except ValueError: v=0.
    print '\n\t%s (%f V), ' % (s,v*5.0/255.)
    
    # Handle RS-485
    rs485.write('*R01\r\n')
    time.sleep(0.05)
    while len(s)<1024:
        s+=rs485.read(1)
        if s[-1] == '\n':
            s=s.strip()
            break
    print s

    # Handle pulse meter

    
except KeyboardInterrupt: # If CTRL+C is pressed, exit cleanly:
    GPIO.cleanup() # cleanup all GPIO
    arduino.close()
    rs485.close()
    print '\n'
