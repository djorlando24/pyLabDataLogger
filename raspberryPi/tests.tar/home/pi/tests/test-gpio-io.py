#!/usr/bin/env python
# External module imports
import RPi.GPIO as GPIO
import time
import sys

# Pin Definitons:
ledPins = [21,22,23]
butPins = [16,17,18] 

# Pin Setup:
GPIO.setmode(GPIO.BCM) # Broadcom pin-numbering scheme
for ledPin in ledPins:
        GPIO.setup(ledPin, GPIO.OUT) # LED pin set as output
        GPIO.output(ledPin, GPIO.LOW)
for butPin in butPins:
	GPIO.setup(butPin, GPIO.IN, pull_up_down=GPIO.PUD_UP) # Button pin set as input w/ pull-up

print("Here we go! Press CTRL+C to exit")
try:
  while 1:
    for i in range(len(butPins)):
        butPin=butPins[i]
        ledPin=ledPins[i]
        if GPIO.input(butPin): # button is released
            GPIO.output(ledPin, GPIO.LOW)
        else: # button is pressed:
            GPIO.output(ledPin, GPIO.HIGH)
            time.sleep(0.05)
        sys.stdout.write('%i=%i ' % (butPin,GPIO.input(butPin)))
    sys.stdout.write('\n')
except KeyboardInterrupt: # If CTRL+C is pressed, exit cleanly:
    GPIO.cleanup() # cleanup all GPIO
